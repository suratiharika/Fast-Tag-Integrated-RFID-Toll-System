#include "lcd.h"
#include "delay.h"

int dist,adcval,vol;
float ear;

int main()
{
	initLCD();
	Init_ADC();
	while(1)
	{
		Read_ADC(1,&adcval,&ear);
		vol=ear*(1023/5);
		dist=(6787/(vol-3))-4;
		cmdLCD(0x80);
		u32LCD(dist);
		delay_ms(500);
	}
}